package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PaymentModel {
	@Id
	
	String name;
	double cardnumber;
	String cname;
	String scode;
	int ammount;
	public PaymentModel() {
		
	}
	
	
	public PaymentModel( String name, double cardnumber, String cname, String scode, int ammount) {
		super();
		
		this.name = name;
		this.cardnumber = cardnumber;
		this.cname = cname;
		this.scode = scode;
		this.ammount = ammount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(double cardnumber) {
		this.cardnumber = cardnumber;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getScode() {
		return scode;
	}
	public void setScode(String scode) {
		this.scode = scode;
	}
	public int getAmmount() {
		return ammount;
	}
	public void setAmmount(int ammount) {
		this.ammount = ammount;
	}


	
	

}
