package com.Edubridge;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.DAO.Daopayment;
@Service
public class PaymentService {
	@Autowired
	Daopayment d;
	
public void savepaymen(PaymentModel p) {
	d.save(p);
	
}
public List getAllBills() {
	return d.findAll();
}
}

