package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class loginModel1 {
	@Id
    String emailid;
	String password;
	String name;
	String message;
	
	public loginModel1() {
		
	}
	public loginModel1(String emailid, String password, String name) {
		super();
		this.emailid = emailid;
		this.password = password;
		this.name = name;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
