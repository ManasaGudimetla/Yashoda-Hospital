package com.Edubridge;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class AppointmentLatterController {
	@Autowired
	AppointmentLatterService ap;
	@PostMapping("submit")
	public void saveA(@RequestBody AppointmentLatterModel d) {
//		System.out.println(ap.getId());
		ap.saveAp(d);
	}
//	@PostMapping("vie")
//	public AppointmentLatterModel getApp(@RequestBody AppointmentLatterModel id){
//		int id1=id.getId();
//		return ap.getAppById(id1);
//}
	@GetMapping("vv")
	public List<AppointmentLatterModel> getApp(){
		return ap.getAllApp();
	}
//	@GetMapping("see")
//public ResponseEntity<List<AppointmentLatterModel>> getAppByName(@RequestParam String dname){
//		
//	return new ResponseEntity<List<AppointmentLatterModel>>(ap.findByName);
//}

}