package com.Edubridge;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class PatientController {
	@Autowired
	PatientService a;
	@PostMapping("send")
	public void savep(@RequestBody PatientModel p) {
		a.savepatient(p);
	}
	@GetMapping("view")
	public List<PatientModel> getAll(){
		return a.getAllPatients();
	}
	@PostMapping("delet")
	public void deleteA(@RequestBody PatientModel p) {
		a.deletep(p);

}
//	@PostMapping("signin")
//	public ResponseEntity<?> signInUser(@RequestBody signUpModelOrEntity signInEntityData) {
//		signUpModelOrEntity signInObj=signUpRepo.findByEmail(signInEntityData.getEmail());
//		if(signInObj.getPassToken().equals(signInObj.getPassToken()) && signInObj.getEmail().equals(signInObj.getEmail()))
//			return ResponseEntity.ok(signInObj);
//			return (ResponseEntity<?>) ResponseEntity.internalServerError();
//		
	//}
}
