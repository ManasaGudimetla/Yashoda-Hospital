package com.Edubridge;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin(origins="http://localhost:4200")
public class PaymentController {
	@Autowired
	PaymentService py;
	@PostMapping("pay")
	public void savep(@RequestBody PaymentModel p) {
		
//		System.out.println(p.getId());
		py.savepaymen(p);
	}
	@GetMapping("vw")
	public List<PatientModel> getAll(){
		return py.getAllBills();
	}
}
