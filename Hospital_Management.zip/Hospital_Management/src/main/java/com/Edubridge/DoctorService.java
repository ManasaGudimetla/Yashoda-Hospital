package com.Edubridge;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.DAO.Daodlogin;
@Service
public class DoctorService {
	@Autowired
	Daodlogin dl;
	public void savedoctor(DoctorModel d) {
		dl.save(d);
	}
	public List getAllDc() {
		return dl.findAll();
	}


}
