package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class PatientModel {
	@Id
	
	String name;
	double cnumber;
	String problem;
	String gender;
	String address;
	String date;
	
	public PatientModel() {
		
	}
	
	
	public PatientModel( String name, double cnumber, String problem, String gender, String address, String date
			) {
		super();
		
		this.name = name;
		this.cnumber = cnumber;
		this.problem = problem;
		this.gender = gender;
		this.address = address;
		this.date = date;
		
	}

public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCnumber() {
		return cnumber;
	}
	public void setCnumber(double cnumber) {
		this.cnumber = cnumber;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	
	}
	

