package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RegisterModel {
	@Id
String name;
String emailid;
String password;
public RegisterModel() {
	
}
public RegisterModel(String name, String emailid, String password) {
	super();
	this.name = name;
	this.emailid = emailid;
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}
