package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DoctorModel {
	@Id
	String name;
	String emailid;
	String specialization;
	double cnumber;
	String address;
	
	
public DoctorModel() {
		
	}
	
	public DoctorModel( String name, String emailid, String specialization, double cnumber, String address) {
	super();
	
	this.name = name;
	this.emailid = emailid;
	this.specialization = specialization;
	this.cnumber = cnumber;
	this.address = address;
}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public double getCnumber() {
		return cnumber;
	}
	public void setCnumber(double cnumber) {
		this.cnumber = cnumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	
}
