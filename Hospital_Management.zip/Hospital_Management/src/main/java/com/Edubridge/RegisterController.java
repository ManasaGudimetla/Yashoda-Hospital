package com.Edubridge;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.DAO.DaoHospital;
import com.Edubridge.DAO.DaoRegister;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class RegisterController {
	@Autowired
	private DaoRegister dr;
	@PostMapping("PRegister")
	public ResponseEntity<?> signUpUser(@RequestBody RegisterModel signUpEntityData) {
		return ResponseEntity.ok(dr.save(signUpEntityData));
	}
	@PostMapping("plogin")
	public ResponseEntity<?> signInUser(@RequestBody RegisterModel signInEntityData) {
		RegisterModel ps=dr.findByEmailid(signInEntityData.getEmailid());
		if(ps.getPassword().equals(ps.getPassword()) && ps.getEmailid().equals(ps.getEmailid()))
			return ResponseEntity.ok(ps);
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
}

}
