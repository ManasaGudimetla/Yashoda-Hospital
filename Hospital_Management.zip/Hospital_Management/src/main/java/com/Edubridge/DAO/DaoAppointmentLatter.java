package com.Edubridge.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.Edubridge.AppointmentLatterModel;

public interface DaoAppointmentLatter extends JpaRepository<AppointmentLatterModel,Integer>{



//	List< AppointmentLatterModel>  findByName(String name);

}
