package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;


import com.Edubridge.loginModel1;

public interface Daologin extends JpaRepository<loginModel1,Integer> {

	

}
