package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.PaymentModel;

public interface Daopayment extends JpaRepository<PaymentModel,Integer>{

}
