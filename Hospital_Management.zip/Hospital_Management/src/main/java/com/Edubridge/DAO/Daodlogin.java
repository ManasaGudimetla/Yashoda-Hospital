package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.DoctorModel;

public interface Daodlogin extends JpaRepository<DoctorModel,Integer>{

}
