package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.PatientModel;

public interface DaoPatient extends JpaRepository<PatientModel,Integer>{

}
