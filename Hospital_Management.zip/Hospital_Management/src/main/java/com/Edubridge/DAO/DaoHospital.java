package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.HospitalModel;

public interface DaoHospital extends JpaRepository<HospitalModel,Integer> {

	HospitalModel findByEmailid(String emailid);

}
