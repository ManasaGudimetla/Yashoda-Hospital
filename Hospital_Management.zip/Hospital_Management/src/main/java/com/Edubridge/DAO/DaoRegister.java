package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;


import com.Edubridge.RegisterModel;



public interface DaoRegister  extends JpaRepository<RegisterModel,Integer> {
	RegisterModel findByEmailid(String emailid);

}
