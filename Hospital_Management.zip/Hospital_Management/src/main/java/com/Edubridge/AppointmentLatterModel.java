package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AppointmentLatterModel {
	@Id
	int id;
	String pname;
	String dname;
	String problem;
	String specialization;
	String date;
	public AppointmentLatterModel() {
		
	}
	
	public AppointmentLatterModel(int id, String pname, String dname, String problem, String specialization,
			String date) {
		super();
		this.id = id;
		this.pname = pname;
		this.dname = dname;
		this.problem = problem;
		this.specialization = specialization;
		this.date = date;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
}
