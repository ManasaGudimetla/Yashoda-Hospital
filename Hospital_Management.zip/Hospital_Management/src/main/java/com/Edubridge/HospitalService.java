package com.Edubridge;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.DAO.DaoHospital;

@Service
public class HospitalService {
	@Autowired 
	DaoHospital dh;
//	public List getAllpatients() {
//		return dh.findAll();
//	}
	public void savepatient(HospitalModel p) {
		dh.save(p);
	}
	public void delete(HospitalModel s) {
		dh.delete(s);
}
}
