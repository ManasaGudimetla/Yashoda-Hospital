package com.Edubridge;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity


public class HospitalModel {
	@Id
	
	int id;
	String name;
	String emailid;
	String password;
public HospitalModel() {
		
	}
	public HospitalModel(int id, String name, String emailid, String password) {
		super();
		this.id = id;
		this.name = name;
		this.emailid = emailid;
		this.password = password;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
