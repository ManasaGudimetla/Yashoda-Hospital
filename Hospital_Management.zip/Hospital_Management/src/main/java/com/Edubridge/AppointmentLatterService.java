package com.Edubridge;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.Edubridge.DAO.DaoAppointmentLatter;

@Service
public class AppointmentLatterService {
	@Autowired
	DaoAppointmentLatter ad;
	public HttpStatus findByName;
	public void saveAp(AppointmentLatterModel da) {
		ad.save(da);
}
//	public AppointmentLatterModel  getAppById(int id) {
//		Optional<AppointmentLatterModel>pm=ad.findById(id);
//	if(pm.isPresent()) {
//		return pm.get();
//	}else
//	return null;
//}

	public List getAllApp() {
		return ad.findAll();
	}


	
}
