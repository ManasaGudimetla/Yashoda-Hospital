package com.Edubridge;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.DAO.DaoHospital;
import com.Edubridge.DAO.Daologin;

@Service
public class loginService {
	@Autowired
	Daologin dl;
	public void savepatient(loginModel1 p) {
		dl.save(p);
	}
}
