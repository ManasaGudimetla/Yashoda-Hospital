package com.Edubridge;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;


import com.Edubridge.DAO.DaoPatient;


@Service
public class PatientService {
	@Autowired
	DaoPatient p;
	public void savepatient(PatientModel d) {
		p.save(d);
	}
	public List getAllPatients() {
		return p.findAll();
	}
	public void deletep(PatientModel a) {
		p.delete(a);
}
//	public interface SignUpRepository extends JpaRepository<signUpModelOrEntity, Integer>{
//	signUpModelOrEntity findByEmail(String email);
//}
}