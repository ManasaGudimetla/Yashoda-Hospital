import { NgModule } from '@angular/core';
import { RouterModule, Routes ,Router} from '@angular/router';

import { ALoginComponent } from './component/a-login/a-login.component';
import { AddminComponent } from './component/addmin/addmin.component';
import { AppointmentComponent } from './component/appointment/appointment.component';
import { BillsComponent } from './component/bills/bills.component';
import { DLoginComponent } from './component/d-login/d-login.component';
import { DashBordComponent } from './component/dash-bord/dash-bord.component';
import { DetailsComponent } from './component/details/details.component';
import { DloginComponent } from './component/dlogin/dlogin.component';
import { DoctorComponent } from './component/doctor/doctor.component';
import { DoctorsComponent } from './component/doctors/doctors.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { Login1Component } from './component/login1/login1.component';
import { LogoutComponent } from './component/logout/logout.component';
import { PLoginComponent } from './component/p-login/p-login.component';
import { PaymentComponent } from './component/payment/payment.component';
import { PregisterComponent } from './component/pregister/pregister.component';
import { RegisterComponent } from './component/register/register.component';
import { Register1Component } from './component/register1/register1.component';
import { HeaderComponent } from './header/header.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent},
  {path:'payment',component:  PaymentComponent},
  {path:'appointment',component:AppointmentComponent},
   {path:'p-login',component: PLoginComponent },
  {path:'doctors',component: DoctorsComponent },
  {path:'dlogin',component:DloginComponent },
  {path:'d-login',component:DLoginComponent },
  {path:'a-login',component:ALoginComponent },
  {path:'dash-bord',component:DashBordComponent },
  {path:'register',component:RegisterComponent },
  {path:'login1',component:Login1Component },
   {path:'register1',component:Register1Component },
   {path:'bills',component:BillsComponent },
   {path:'header',component:HeaderComponent },
   {path:'logout',component:LogoutComponent },
   {path:'details',component:DetailsComponent },
   {path:'addmin',component:AddminComponent},
   {path:'doctor',component:DoctorComponent},
   {path:'pregister',component:PregisterComponent},
   
   
];

@NgModule({
  imports: [RouterModule.forRoot(routes)], 
  exports: [RouterModule],
 
})
export class AppRoutingModule { }
