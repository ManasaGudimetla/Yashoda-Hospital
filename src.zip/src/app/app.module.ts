import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { FooterComponent } from './component/footer/footer.component';
import { IntroComponent } from './component/intro/intro.component';
import { NavigationComponent } from './component/navigation/navigation.component';
import { PaymentComponent } from './component/payment/payment.component';
import { AppointmentComponent } from './component/appointment/appointment.component';
import { DLoginComponent } from './component/d-login/d-login.component';
import { PLoginComponent } from './component/p-login/p-login.component';
import { ALoginComponent } from './component/a-login/a-login.component';
import { DoctorsComponent } from './component/doctors/doctors.component';
import { DloginComponent } from './component/dlogin/dlogin.component';
import { DashBordComponent } from './component/dash-bord/dash-bord.component';
import { Router } from '@angular/router';
import { RegisterComponent } from './component/register/register.component';
import { Login1Component } from './component/login1/login1.component';
import { Register1Component } from './component/register1/register1.component';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { BillsComponent } from './component/bills/bills.component';
import { LogoutComponent } from './component/logout/logout.component';
import { DetailsComponent } from './component/details/details.component';
import { AddminComponent } from './component/addmin/addmin.component';
import { DoctorComponent } from './component/doctor/doctor.component';
import { PregisterComponent } from './component/pregister/pregister.component';

@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    IntroComponent,
    FooterComponent,
    HomeComponent,
    LoginComponent,
    PaymentComponent,
    AppointmentComponent,
    DLoginComponent,
    PLoginComponent,
    ALoginComponent,
    DoctorsComponent,
    DloginComponent,
    DashBordComponent,
    RegisterComponent,
    Login1Component,
    Register1Component,
    HeaderComponent,
    BillsComponent,
    LogoutComponent,
    DetailsComponent,
    AddminComponent,
    DoctorComponent,
    PregisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
