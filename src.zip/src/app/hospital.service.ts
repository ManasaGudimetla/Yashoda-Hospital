import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class HospitalService {
 
  url1="http://localhost:8080/Register"
  url2="http://localhost:8080/log"
  url3="http://localhost:8080/dlogin"
  url4="http://localhost:8080/send"
  url5="http://localhost:8080/signin"
  url6="http://localhost:8080/submit"
  url7="http://localhost:8080/update"
  url8="http://localhost:8080/pay"
  url9="http://localhost:8080/Register"
  url10="http://localhost:8080/view"
  url11="http://localhost:8080/delete"
  url12="http://localhost:8080/Register"
  url13="http://localhost:8080/delet"
  url14="http://localhost:8080/vie"
  url15="http://localhost:8080/vw"
  url16="http://localhost:8080/logout"
  url17="http://localhost:8080/vv"
  url18="http://localhost:8080/dd"
  url19="http://localhost:8080/plogin"
  url20="http://localhost:8080/PRegister"
  constructor(private h1:HttpClient) {  }
   insertData1(data: any) {
     return this.h1.post(this.url1,data)
   }
   
  DloginData(data: any) {
    return this.h1.post(this.url3,data)
  }
  
  logInData(data:any){
    return this.h1.post(this.url2,data)
  }
  insertPatientData(data:any){
    return this.h1.post(this.url4,data)
  }
  insertAppData(data:any){
    return this.h1.post(this.url6,data)
  }
  insertDoctorData(data:any){
    return this.h1.post(this.url7,data)
  }
  insertPaytData(data:any){
    console.log(data);
    return this.h1.post(this.url8,data)
  }
  insert(data:any){
    return this.h1.post(this.url9,data)
  }
  signInData(signInRec :any){
    console.log(signInRec.value);
    return this.h1.post(this.url5,signInRec)
  }
 
  viewPatients(){
    return this.h1.get(this.url10);
  }
  insertRegData(data:any){

    return this.h1.post(this.url12,data)
  }
  deleteData(data:any){
    return this.h1.post(this.url13,data)
  }
  viewAppointmentById(data:any){
    return this.h1.post(this.url14,data);
  }
  viewBills(){
   return this.h1.get(this.url15);
  }
  deletelog(data:any){
    return this.h1.post(this.url16,data)
  }
  viewAppointment(){
    return this.h1.get(this.url17);
   }
   viewdetails(){
    return this.h1.get(this.url18);
   }
   insertpData(data:any){
    return this.h1.post(this.url20,data)
   }
}



