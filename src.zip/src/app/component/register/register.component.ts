import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor() { }
//   insertData(insert:any){
//   this.ps.insertData(insert.value).subscribe();
//  }
  ngOnInit(): void {
  }

}
