import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-d-login',
  templateUrl: './d-login.component.html',
  styleUrls: ['./d-login.component.css']
})
export class DLoginComponent implements OnInit {

  constructor(private ps:HospitalService,private router:Router) { }
  insertDoctorData(insert:any){
    this.ps.insertDoctorData(insert.value).subscribe();
    this.router.navigate(['dash-bord']);
  }
  ngOnInit(): void {
  }

}
