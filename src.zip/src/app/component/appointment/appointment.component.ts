import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {
  
  constructor(private ps:HospitalService,private router:Router) { }
  insertPatientData(insert:any){
    this.ps.insertPatientData(insert.value).subscribe(response=>{
      alert("Appointment submited Successfull!!");
    this.router.navigate(['a-login']);
  },error=>alert("  Invalid Credentials!! Please try again"));
     
  }

  ngOnInit(): void {
  }

}
