import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';
import { Register1Component } from '../register1/register1.component';

@Component({
  selector: 'app-login1',
  templateUrl: './login1.component.html',
  styleUrls: ['./login1.component.css']
})
export class Login1Component implements OnInit {

  constructor(private ps:HospitalService , private router:Router) { }
  insertAppData(insert:any){
    this.ps. insertAppData(insert.value).subscribe( response=>{
      alert("Submited  Successfull!!");
      this.router.navigate(['dash-bord']);
    },error=>alert(" Invalid Credentials!! Please try again"));
      
  }
  
 
     

   


  ngOnInit(): void {
  }

}
