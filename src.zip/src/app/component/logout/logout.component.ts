import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private ps:HospitalService,private router:Router) { }
  deletelog(data:any){
    this.ps.deletelog(data.value).subscribe();
    this.router.navigate(['home']);
      }

  ngOnInit(): void {
  }

}
