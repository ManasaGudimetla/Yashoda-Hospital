import { Component, OnInit } from '@angular/core';
import { HospitalService } from 'src/app/hospital.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  constructor(private ps:HospitalService,private router:Router) { }
  insertPaytData(insert:any){
    this.ps.insertPaytData(insert.value).subscribe( response=>{
      alert("Payment Successfull!!");
    this.router.navigate(['appointment']);
  },error=>alert("Payment not successfull!! Please try again"));
  }
  ngOnInit(): void {
  }

}
