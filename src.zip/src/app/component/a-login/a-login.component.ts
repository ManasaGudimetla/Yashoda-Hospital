import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-a-login',
  templateUrl: './a-login.component.html',
  styleUrls: ['./a-login.component.css']
})
export class ALoginComponent implements OnInit {
 

  constructor(private ps:HospitalService , private router:Router) { 
    
  }
 
  // logInInfo(logInData:any){/**method getting called from API with user given data */
  //   console.log(logInData.value);
  //   this.ps.logInData(logInData.value).subscribe(   response=>{
  //     alert("Login Successfull!!");
  //     this.router.navigate(['home']);
  //   },error=>alert("Login is not successfull!! Please try again"));/* calling service method. Subscribing the service the method insertRegData to process the received data */    
  // }
 
  ngOnInit(): void {
  }

}
