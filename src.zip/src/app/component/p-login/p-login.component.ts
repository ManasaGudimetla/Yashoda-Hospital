import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-p-login',
  templateUrl: './p-login.component.html',
  styleUrls: ['./p-login.component.css']
})
export class PLoginComponent implements OnInit {

  constructor(private ps:HospitalService,private router:Router ){ 
     this.viewAppointment();
    
  }
 
  
  Appointmenrs:any;
  viewAppointment(){
   this.ps.viewAppointment().subscribe((result:any)=>{this.Appointmenrs=result});
  
  }
  
//   Appointments:any=0;
//   getById(data:any){
//     console.log(data);
//  this.ps.viewAppointmentById(data).subscribe((resp:any)=>{this.Appointments=resp;});
//  this.router.navigate(['a-login']);
//}
  ngOnInit(): void {
  }

}

