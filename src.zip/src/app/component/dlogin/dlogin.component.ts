import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-dlogin',
  templateUrl: './dlogin.component.html',
  styleUrls: ['./dlogin.component.css']
})
export class DloginComponent implements OnInit {

  constructor(private ps:HospitalService,private router:Router) { }
  deleteData(data:any){
    this.ps.deleteData(data.value).subscribe();
    this.router.navigate(['dash-bord']);
      }
  ngOnInit(): void {
  }

}
