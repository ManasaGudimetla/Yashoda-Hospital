import { Component, OnInit } from '@angular/core';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-bills',
  templateUrl: './bills.component.html',
  styleUrls: ['./bills.component.css']
})
export class BillsComponent implements OnInit {

  constructor(private ps:HospitalService) {
    this.viewBills();
   }
  

Bills:any;
viewBills(){
 this.ps.viewBills().subscribe((result:any)=>{this.Bills=result});

}

  ngOnInit(): void {
  }

}
