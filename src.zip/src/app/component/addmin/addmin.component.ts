import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-addmin',
  templateUrl: './addmin.component.html',
  styleUrls: ['./addmin.component.css']
})
export class AddminComponent implements OnInit {

  constructor(private signInAdd:HospitalService,public router:Router, ) { }
  public userDetails:any;
  signInAddmin(signInRec:any){
    console.log(signInRec.value);
    this.signInAdd.signInData(signInRec.value).subscribe(response=>{
      alert("Login Successfull!!");
      sessionStorage.setItem('loggedInUserDetails',JSON.stringify(response))
      console.log(sessionStorage.getItem('loggedInUserDetails'));
     // console.log(JSON.parse(sessionStorage.getItem('loggedInUserDetails')));      
      this.router.navigate(['dash-bord']);
     
    },error=>alert("Invalid Credentials!! Please try again"));
  }
  ngOnInit(): void {
  }

}
