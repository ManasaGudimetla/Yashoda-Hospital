import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/hospital.service';

@Component({
  selector: 'app-pregister',
  templateUrl: './pregister.component.html',
  styleUrls: ['./pregister.component.css']
})
export class PregisterComponent implements OnInit {

  
  ngOnInit(): void {
  }

}
