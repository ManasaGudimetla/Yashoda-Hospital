import { Component, OnInit } from '@angular/core';
import { HospitalService } from 'src/app/hospital.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-register1',
  templateUrl: './register1.component.html',
  styleUrls: ['./register1.component.css']
})
export class Register1Component implements OnInit {

  constructor(private regObj:HospitalService , private router:Router) { }
  /*Pass data from Registration form*/
  insUserInfo(insRegInfoRec:any){/**method getting called from API with user given data */
    console.log(insRegInfoRec.value);
    this.regObj.insertRegData(insRegInfoRec.value).subscribe(   response=>{
      alert("Registration Successfull!!");
      this.router.navigate(['login']);
    },error=>alert("Registration not successfull!! Please try again"));/* calling service method. Subscribing the service the method insertRegData to process the received data */    
  }
  ngOnInit(): void {
  }

}
